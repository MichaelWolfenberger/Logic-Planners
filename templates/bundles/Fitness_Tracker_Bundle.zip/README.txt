LOGICPLANNERS — FITNESS TRACKER BUNDLE
======================================

Thank you for your purchase! This bundle contains 4 templates:

1. Workout_Tracker.xlsx — workout log, volume & PR tracking
2. Nutrition_Macro_Tracker.xlsx — daily macro log with weekly summary
3. Event_Training_Planner.xlsx — 16-week race/event training plan
4. Body_Progress_Goal_Tracker.xlsx — goals & monthly measurements

GETTING STARTED
1. Open in Excel 2016+, or upload to Google Drive and open with Google Sheets.
2. Blue cells = your inputs. Everything else calculates automatically.
3. Start with the Dashboard tab of each file.

Questions? Reply to your order message and we'll help you out.

LOGICPLANNERS — EVENT PLANNING BUNDLE
=====================================

Thank you for your purchase! This bundle contains 4 templates:

1. Event_Budget_Tracker.xlsx — 13 budget categories with overspend flags
2. Event_Guest_Registration_Manager.xlsx — 500-row attendee list with check-in
3. Event_Project_Timeline.xlsx — tasks across 7 phases with completion tracking
4. Event_Vendor_Logistics_Manager.xlsx — contracts, deposits & load-in schedule

GETTING STARTED
1. Open in Excel 2016+, or upload to Google Drive and open with Google Sheets.
2. Blue cells = your inputs. Everything else calculates automatically.
3. Start with the Dashboard tab of each file.

Questions? Reply to your order message and we'll help you out.

LOGICPLANNERS — WEDDING PLANNING BUNDLE
=======================================

Thank you for your purchase! This bundle contains 4 templates:

1. Wedding_Budget_Tracker.xlsx — budget, vendors & payment schedule
2. Wedding_Guest_RSVP_Manager.xlsx — guest list, meals & table assignments
3. Wedding_Day_Timeline.xlsx — day-of schedule, vendor directory & checklist
4. Honeymoon_Budget_Planner.xlsx — honeymoon budget, itinerary & packing list

GETTING STARTED
1. Open in Excel 2016+, or upload to Google Drive and open with Google Sheets.
2. Blue cells = your inputs. Everything else calculates automatically.
3. Start with the Dashboard tab of each file.

Questions? Reply to your order message and we'll help you out.
